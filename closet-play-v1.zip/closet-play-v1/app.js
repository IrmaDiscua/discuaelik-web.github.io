const STORAGE_KEY = 'closetPlayDataV1';
const categoryLabels = {
  all: 'Todo', tops: 'Blusas', bottoms: 'Pantalones', dresses: 'Vestidos',
  outerwear: 'Chaquetas', shoes: 'Zapatos', accessories: 'Accesorios'
};
const categoryEmoji = {
  tops: '👚', bottoms: '👖', dresses: '👗', outerwear: '🧥', shoes: '👟', accessories: '👜'
};
const slotConfig = [
  { key: 'top', label: 'Parte superior', categories: ['tops', 'dresses', 'outerwear'], emoji: '👚' },
  { key: 'bottom', label: 'Parte inferior', categories: ['bottoms'], emoji: '👖' },
  { key: 'shoes', label: 'Zapatos', categories: ['shoes'], emoji: '👟' },
  { key: 'accessory', label: 'Accesorio', categories: ['accessories'], emoji: '👜' }
];

let currentScreen = 'home';
let currentCategory = 'all';
let currentPickerSlot = 'top';
let currentLook = { top: null, bottom: null, shoes: null, accessory: null };
let selectedDate = dateKey(new Date());
let calendarCursor = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let deferredInstallPrompt = null;
let photoDataUrl = '';

const app = document.getElementById('app');
const modalBackdrop = document.getElementById('modalBackdrop');
const addItemModal = document.getElementById('addItemModal');
const settingsModal = document.getElementById('settingsModal');
const toast = document.getElementById('toast');

function seedData() {
  return {
    items: [
      { id: uid(), name: 'Top rosa nube', category: 'tops', color: 'Rosa', style: 'Juvenil', emoji: '👚', image: '', favorite: true },
      { id: uid(), name: 'Jeans azul claro', category: 'bottoms', color: 'Azul', style: 'Casual', emoji: '👖', image: '', favorite: false },
      { id: uid(), name: 'Tenis blancos', category: 'shoes', color: 'Blanco', style: 'Casual', emoji: '👟', image: '', favorite: true },
      { id: uid(), name: 'Bolso lila', category: 'accessories', color: 'Lila', style: 'Juvenil', emoji: '👜', image: '', favorite: true },
      { id: uid(), name: 'Vestido primavera', category: 'dresses', color: 'Multicolor', style: 'Elegante', emoji: '👗', image: '', favorite: false },
      { id: uid(), name: 'Chaqueta denim', category: 'outerwear', color: 'Azul', style: 'Casual', emoji: '🧥', image: '', favorite: false }
    ],
    looks: [],
    schedule: {},
    onboarded: true
  };
}

function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved && saved.items ? saved : seedData();
  } catch {
    return seedData();
  }
}
let data = loadData();
saveData();

function saveData() { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
function uid() { return `${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`; }
function dateKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function itemVisual(item) {
  if (!item) return '';
  return item.image ? `<img src="${item.image}" alt="${escapeHtml(item.name)}">` : `<span>${item.emoji || categoryEmoji[item.category]}</span>`;
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2400);
}
function openModal(modal) {
  modalBackdrop.classList.remove('hidden');
  modal.classList.remove('hidden');
}
function closeModals() {
  modalBackdrop.classList.add('hidden');
  document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
}
function formatSelectedDate(key) {
  return new Intl.DateTimeFormat('es-HN', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${key}T12:00:00`));
}

function navigate(screen) {
  currentScreen = screen;
  document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.screen === screen));
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function render() {
  const screens = { home: renderHome, wardrobe: renderWardrobe, create: renderCreate, calendar: renderCalendar, favorites: renderFavorites };
  app.innerHTML = screens[currentScreen]();
  bindScreenEvents();
}

function renderHome() {
  const todayLookId = data.schedule[dateKey(new Date())];
  const todayLook = data.looks.find(l => l.id === todayLookId);
  return `
    <section>
      <div class="hero-card">
        <p class="eyebrow" style="color:white;opacity:.86">Bienvenido a tu armario</p>
        <h2>${todayLook ? 'Tu look de hoy está listo' : 'Juega, combina y crea tu estilo'}</h2>
        <p>${todayLook ? escapeHtml(todayLook.name) : 'Organiza tu ropa real y descubre combinaciones bonitas sin probarte todo.'}</p>
        <div class="hero-actions">
          <button class="secondary-button" data-go="create">Crear un look</button>
          <button class="primary-button" style="background:rgba(45,41,64,.22);box-shadow:none" data-open-add>Agregar ropa</button>
        </div>
        <div class="hero-badge">👗</div>
      </div>

      <div class="stats-grid">
        <div class="stat-card"><span>👚</span><strong>${data.items.length}</strong><small>Prendas</small></div>
        <div class="stat-card"><span>✨</span><strong>${data.looks.length}</strong><small>Looks</small></div>
        <div class="stat-card"><span>💖</span><strong>${data.items.filter(i => i.favorite).length}</strong><small>Favoritas</small></div>
      </div>

      <div class="section-title"><h3>¿Qué hacemos hoy?</h3></div>
      <div class="quick-grid">
        <button class="quick-card" data-open-add><span>📸</span><strong>Agregar prenda</strong><small>Fotografía algo de tu armario</small></button>
        <button class="quick-card" data-go="create"><span>🎨</span><strong>Combinar ropa</strong><small>Arma un look a tu manera</small></button>
        <button class="quick-card" data-go="calendar"><span>🗓️</span><strong>Planificar semana</strong><small>Decide qué usarás cada día</small></button>
        <button class="quick-card" data-random-look><span>🎲</span><strong>Sorpréndeme</strong><small>Genera una combinación al azar</small></button>
      </div>
    </section>`;
}

function renderWardrobe() {
  const categories = Object.keys(categoryLabels);
  const items = currentCategory === 'all' ? data.items : data.items.filter(i => i.category === currentCategory);
  return `
    <section>
      <div class="screen-header">
        <div><p class="eyebrow">Tu colección</p><h2>Mi armario</h2><p>${data.items.length} prendas registradas</p></div>
        <button class="small-button" data-open-add>＋ Agregar</button>
      </div>
      <div class="category-strip">
        ${categories.map(cat => `<button class="category-chip ${currentCategory === cat ? 'active' : ''}" data-category="${cat}">${categoryLabels[cat]}</button>`).join('')}
      </div>
      <div class="wardrobe-grid">
        ${items.length ? items.map(item => `
          <article class="clothing-card">
            <div class="clothing-image">${itemVisual(item)}</div>
            <button class="delete-item" data-delete-item="${item.id}" aria-label="Eliminar">🗑️</button>
            <button class="favorite-toggle" data-favorite-item="${item.id}" aria-label="Favorito">${item.favorite ? '💖' : '🤍'}</button>
            <div class="clothing-info"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.color)} · ${escapeHtml(item.style)}</small></div>
          </article>`).join('') : `
          <div class="empty-state"><span>🛍️</span><h3>Aquí todavía no hay prendas</h3><p>Agrega una foto para comenzar.</p><button class="primary-button" data-open-add>Agregar prenda</button></div>`}
      </div>
    </section>`;
}

function renderCreate() {
  const currentSlot = slotConfig.find(s => s.key === currentPickerSlot);
  const available = data.items.filter(i => currentSlot.categories.includes(i.category));
  return `
    <section>
      <div class="screen-header"><div><p class="eyebrow">Laboratorio de estilo</p><h2>Crear look</h2><p>Toca cada espacio para elegir una prenda</p></div></div>
      <div class="look-builder">
        <div class="look-stage">
          <div class="look-stage-top"><h3>Mi combinación</h3><button class="small-button" data-clear-look>Limpiar</button></div>
          <div class="look-slots">
            ${slotConfig.map(slot => {
              const item = data.items.find(i => i.id === currentLook[slot.key]);
              return `<button class="look-slot ${item ? 'filled' : ''}" data-slot="${slot.key}">
                ${item ? itemVisual(item) : `<div><span class="emoji">${slot.emoji}</span><small>Elegir ${slot.label.toLowerCase()}</small></div>`}
                <span class="slot-label">${slot.label}</span>
              </button>`;
            }).join('')}
          </div>
        </div>
        <div class="picker-panel">
          <h3>Elige: ${currentSlot.label}</h3>
          <div class="picker-items">
            ${available.length ? available.map(item => `<button class="picker-item ${currentLook[currentPickerSlot] === item.id ? 'active' : ''}" data-pick-item="${item.id}">
              <div class="picker-thumb">${itemVisual(item)}</div><small>${escapeHtml(item.name)}</small>
            </button>`).join('') : `<div class="empty-state" style="min-width:100%;padding:22px"><span>📸</span><h3>Falta esta categoría</h3><p>Agrega prendas para poder combinarlas.</p><button class="primary-button" data-open-add>Agregar</button></div>`}
          </div>
        </div>
        <div class="builder-actions">
          <button class="ghost-button" data-random-look>🎲 Aleatorio</button>
          <button class="secondary-button" data-go="wardrobe">👚 Ver armario</button>
          <button class="primary-button" data-save-look>Guardar este look</button>
        </div>
      </div>
    </section>`;
}

function renderCalendar() {
  const year = calendarCursor.getFullYear();
  const month = calendarCursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const offset = (firstDay.getDay() + 6) % 7;
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push('<span class="day-button blank"></span>');
  for (let d = 1; d <= lastDay.getDate(); d++) {
    const key = dateKey(new Date(year, month, d));
    const classes = ['day-button'];
    if (key === dateKey(new Date())) classes.push('today');
    if (key === selectedDate) classes.push('selected');
    if (data.schedule[key]) classes.push('has-look');
    cells.push(`<button class="${classes.join(' ')}" data-date="${key}">${d}</button>`);
  }
  const assignedLook = data.looks.find(l => l.id === data.schedule[selectedDate]);
  return `
    <section>
      <div class="screen-header"><div><p class="eyebrow">Planifica con estilo</p><h2>Calendario</h2><p>Guarda un look para cada ocasión</p></div></div>
      <div class="calendar-card">
        <div class="calendar-toolbar"><button data-calendar-prev>‹</button><h3>${new Intl.DateTimeFormat('es-HN',{month:'long',year:'numeric'}).format(calendarCursor)}</h3><button data-calendar-next>›</button></div>
        <div class="weekdays"><span>Lun</span><span>Mar</span><span>Mié</span><span>Jue</span><span>Vie</span><span>Sáb</span><span>Dom</span></div>
        <div class="calendar-grid">${cells.join('')}</div>
      </div>
      <div class="schedule-panel">
        <h3 style="text-transform:capitalize">${formatSelectedDate(selectedDate)}</h3>
        <p>${assignedLook ? `Tienes asignado: ${escapeHtml(assignedLook.name)}` : 'Todavía no has elegido un look para este día.'}</p>
        <select class="schedule-select" id="scheduleLookSelect">
          <option value="">Sin look asignado</option>
          ${data.looks.map(l => `<option value="${l.id}" ${assignedLook?.id === l.id ? 'selected' : ''}>${escapeHtml(l.name)}</option>`).join('')}
        </select>
        <button class="primary-button" data-assign-look style="width:100%">Guardar planificación</button>
      </div>
    </section>`;
}

function renderFavorites() {
  const favoriteItems = data.items.filter(i => i.favorite);
  return `
    <section>
      <div class="screen-header"><div><p class="eyebrow">Tus elegidos</p><h2>Favoritos</h2><p>Looks y prendas que amas</p></div></div>
      <div class="section-title"><h3>Looks guardados</h3><button data-go="create">Crear nuevo</button></div>
      ${data.looks.length ? data.looks.map(look => renderLookCard(look)).join('') : `<div class="empty-state"><span>✨</span><h3>Aún no guardas looks</h3><p>Crea una combinación y aparecerá aquí.</p><button class="primary-button" data-go="create">Crear mi primer look</button></div>`}
      <div class="section-title"><h3>Prendas favoritas</h3><button data-go="wardrobe">Ver armario</button></div>
      <div class="wardrobe-grid">
        ${favoriteItems.length ? favoriteItems.map(item => `<article class="clothing-card"><div class="clothing-image">${itemVisual(item)}</div><button class="favorite-toggle" data-favorite-item="${item.id}">💖</button><div class="clothing-info"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.color)} · ${escapeHtml(item.style)}</small></div></article>`).join('') : `<div class="empty-state"><span>🤍</span><h3>No hay favoritas todavía</h3><p>Toca el corazón de una prenda para guardarla aquí.</p></div>`}
      </div>
    </section>`;
}

function renderLookCard(look) {
  return `<article class="look-card">
    <div class="look-card-head"><div><h3>${escapeHtml(look.name)}</h3><small>${new Intl.DateTimeFormat('es-HN',{day:'numeric',month:'short'}).format(new Date(look.createdAt))}</small></div><span>💖</span></div>
    <div class="look-preview">${slotConfig.map(slot => {
      const item = data.items.find(i => i.id === look.items[slot.key]);
      return `<div class="look-piece">${item ? itemVisual(item) : slot.emoji}</div>`;
    }).join('')}</div>
    <div class="look-card-actions"><button class="ghost-button" data-use-look="${look.id}">Editar</button><button style="background:#ffe7ef;color:#c63b6f" data-delete-look="${look.id}">Eliminar</button></div>
  </article>`;
}

function bindScreenEvents() {
  document.querySelectorAll('[data-go]').forEach(el => el.addEventListener('click', () => navigate(el.dataset.go)));
  document.querySelectorAll('[data-open-add]').forEach(el => el.addEventListener('click', () => openModal(addItemModal)));
  document.querySelectorAll('[data-category]').forEach(el => el.addEventListener('click', () => { currentCategory = el.dataset.category; render(); }));
  document.querySelectorAll('[data-favorite-item]').forEach(el => el.addEventListener('click', () => toggleFavorite(el.dataset.favoriteItem)));
  document.querySelectorAll('[data-delete-item]').forEach(el => el.addEventListener('click', () => deleteItem(el.dataset.deleteItem)));
  document.querySelectorAll('[data-slot]').forEach(el => el.addEventListener('click', () => { currentPickerSlot = el.dataset.slot; render(); }));
  document.querySelectorAll('[data-pick-item]').forEach(el => el.addEventListener('click', () => { currentLook[currentPickerSlot] = el.dataset.pickItem; render(); }));
  document.querySelectorAll('[data-random-look]').forEach(el => el.addEventListener('click', randomizeLook));
  document.querySelectorAll('[data-clear-look]').forEach(el => el.addEventListener('click', () => { currentLook = { top:null,bottom:null,shoes:null,accessory:null }; render(); }));
  document.querySelectorAll('[data-save-look]').forEach(el => el.addEventListener('click', saveCurrentLook));
  document.querySelectorAll('[data-calendar-prev]').forEach(el => el.addEventListener('click', () => { calendarCursor = new Date(calendarCursor.getFullYear(), calendarCursor.getMonth()-1,1); render(); }));
  document.querySelectorAll('[data-calendar-next]').forEach(el => el.addEventListener('click', () => { calendarCursor = new Date(calendarCursor.getFullYear(), calendarCursor.getMonth()+1,1); render(); }));
  document.querySelectorAll('[data-date]').forEach(el => el.addEventListener('click', () => { selectedDate = el.dataset.date; render(); }));
  document.querySelectorAll('[data-assign-look]').forEach(el => el.addEventListener('click', assignLook));
  document.querySelectorAll('[data-delete-look]').forEach(el => el.addEventListener('click', () => deleteLook(el.dataset.deleteLook)));
  document.querySelectorAll('[data-use-look]').forEach(el => el.addEventListener('click', () => useLook(el.dataset.useLook)));
}

function toggleFavorite(id) {
  const item = data.items.find(i => i.id === id);
  if (!item) return;
  item.favorite = !item.favorite;
  saveData(); render();
}
function deleteItem(id) {
  const item = data.items.find(i => i.id === id);
  if (!item || !confirm(`¿Eliminar “${item.name}”?`)) return;
  data.items = data.items.filter(i => i.id !== id);
  Object.keys(currentLook).forEach(k => { if (currentLook[k] === id) currentLook[k] = null; });
  saveData(); render(); showToast('Prenda eliminada');
}
function randomizeLook() {
  slotConfig.forEach(slot => {
    const options = data.items.filter(i => slot.categories.includes(i.category));
    currentLook[slot.key] = options.length ? options[Math.floor(Math.random()*options.length)].id : null;
  });
  currentScreen = 'create';
  document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.screen === 'create'));
  render(); showToast('¡Nueva combinación creada!');
}
function saveCurrentLook() {
  const count = Object.values(currentLook).filter(Boolean).length;
  if (count < 2) { showToast('Elige al menos dos prendas'); return; }
  const name = prompt('Ponle un nombre a este look:', `Look ${data.looks.length + 1}`);
  if (!name) return;
  data.looks.unshift({ id: uid(), name: name.trim().slice(0,40), items: {...currentLook}, createdAt: new Date().toISOString() });
  saveData(); showToast('Look guardado en Favoritos'); navigate('favorites');
}
function assignLook() {
  const select = document.getElementById('scheduleLookSelect');
  if (select.value) data.schedule[selectedDate] = select.value;
  else delete data.schedule[selectedDate];
  saveData(); render(); showToast('Planificación guardada');
}
function deleteLook(id) {
  if (!confirm('¿Eliminar este look guardado?')) return;
  data.looks = data.looks.filter(l => l.id !== id);
  Object.keys(data.schedule).forEach(k => { if (data.schedule[k] === id) delete data.schedule[k]; });
  saveData(); render(); showToast('Look eliminado');
}
function useLook(id) {
  const look = data.looks.find(l => l.id === id);
  if (!look) return;
  currentLook = {...look.items}; navigate('create');
}

// Global navigation and modal controls
document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.screen)));
document.querySelectorAll('[data-close-modal]').forEach(btn => btn.addEventListener('click', closeModals));
modalBackdrop.addEventListener('click', closeModals);
document.getElementById('settingsButton').addEventListener('click', () => openModal(settingsModal));
document.getElementById('profileButton').addEventListener('click', () => showToast('Tu perfil personal llegará en la siguiente versión'));

document.getElementById('itemPhoto').addEventListener('change', event => {
  const file = event.target.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) { showToast('La imagen debe pesar menos de 5 MB'); event.target.value = ''; return; }
  const reader = new FileReader();
  reader.onload = () => {
    photoDataUrl = reader.result;
    document.getElementById('photoPreview').innerHTML = `<img src="${photoDataUrl}" alt="Vista previa">`;
  };
  reader.readAsDataURL(file);
});

document.getElementById('addItemForm').addEventListener('submit', event => {
  event.preventDefault();
  const category = document.getElementById('itemCategory').value;
  data.items.unshift({
    id: uid(),
    name: document.getElementById('itemName').value.trim(),
    category,
    color: document.getElementById('itemColor').value,
    style: document.getElementById('itemStyle').value,
    emoji: categoryEmoji[category],
    image: photoDataUrl,
    favorite: false
  });
  saveData();
  event.target.reset();
  photoDataUrl = '';
  document.getElementById('photoPreview').textContent = '📸';
  closeModals();
  currentCategory = 'all';
  showToast('Prenda guardada en tu armario');
  navigate('wardrobe');
});

document.getElementById('resetButton').addEventListener('click', () => {
  if (!confirm('¿Restablecer Closet Play y borrar tus datos locales?')) return;
  data = seedData(); currentLook = {top:null,bottom:null,shoes:null,accessory:null}; saveData(); closeModals(); render(); showToast('Demostración restablecida');
});

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredInstallPrompt = event;
});
document.getElementById('installButton').addEventListener('click', async () => {
  closeModals();
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
  } else {
    alert('En iPhone abre Closet Play en Safari, toca Compartir y elige “Agregar a pantalla de inicio”.');
  }
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
}

render();
