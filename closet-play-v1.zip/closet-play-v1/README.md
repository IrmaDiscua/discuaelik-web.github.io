# Closet Play v1

Primera versión funcional del armario digital Closet Play.

## Funciones incluidas

- Diseño juvenil en rosa, lila y azul.
- Armario por categorías.
- Carga de fotografías desde cámara o galería.
- Marcado de prendas favoritas.
- Creador de looks por secciones.
- Generador de combinaciones aleatorias.
- Guardado y edición de looks.
- Calendario para planificar conjuntos.
- Almacenamiento local en el dispositivo.
- Configuración PWA para instalarla desde el navegador.

## Probar en una computadora

La aplicación necesita abrirse desde un servidor local para activar todas las funciones PWA. Una opción sencilla es ejecutar dentro de esta carpeta:

```bash
python -m http.server 8000
```

Luego abre `http://localhost:8000` en el navegador.

## Publicación

La carpeta se puede publicar en GitHub Pages, Netlify, Vercel o cualquier alojamiento web estático.
